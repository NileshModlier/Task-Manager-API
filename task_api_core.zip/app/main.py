from fastapi import FastAPI
from .routers_auth import router as auth_router
from .routers_tasks import router as tasks_router
from .database import init_db
from .observability import TimingMiddleware

app = FastAPI(title="Task Manager API")
app.include_router(auth_router)
app.include_router(tasks_router)
app.add_middleware(TimingMiddleware)

@app.on_event("startup")
async def startup():
    await init_db()

@app.get('/health')
async def health():
    return {'ok': True}
