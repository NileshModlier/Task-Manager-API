from jose import jwt, JWTError
from passlib.context import CryptContext
SECRET_KEY='secret'
ALGORITHM='HS256'
pwd_context = CryptContext(schemes=['bcrypt'])

def get_password_hash(p): return pwd_context.hash(p)
def verify(p, h): return pwd_context.verify(p,h)
def create_token(data): return jwt.encode(data, SECRET_KEY, algorithm=ALGORITHM)
