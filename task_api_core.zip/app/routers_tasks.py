from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from .database import SessionLocal
from .models import Task
from .schemas import TaskCreate
router=APIRouter(prefix='/tasks', tags=['tasks'])
async def get_db(): async with SessionLocal() as s: yield s

@router.post('/')
async def create_task(data: TaskCreate, db: AsyncSession=Depends(get_db)):
    t=Task(title=data.title, description=data.description)
    db.add(t)
    await db.commit()
    return {'id':t.id}
