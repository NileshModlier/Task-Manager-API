import time, logging
from starlette.middleware.base import BaseHTTPMiddleware
class TimingMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, req, call_next):
        s=time.time(); res=await call_next(req); d=(time.time()-s)*1000
        logging.info(f"{req.url.path} {d}ms"); return res
