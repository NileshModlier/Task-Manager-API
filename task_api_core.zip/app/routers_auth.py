from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from .database import SessionLocal
from .models import User
from .schemas import UserCreate, Token
from .auth import get_password_hash, verify, create_token

router = APIRouter(prefix='/auth', tags=['auth'])

async def get_db():
    async with SessionLocal() as s: yield s

@router.post('/register')
async def reg(data: UserCreate, db: AsyncSession = Depends(get_db)):
    u = User(email=data.email, hashed_password=get_password_hash(data.password))
    db.add(u)
    await db.commit()
    return {'msg':'ok'}

@router.post('/login', response_model=Token)
async def login(data: UserCreate, db: AsyncSession = Depends(get_db)):
    q = await db.execute(select(User).where(User.email==data.email))
    u = q.scalars().first()
    if not u or not verify(data.password, u.hashed_password):
        raise HTTPException(401,'bad creds')
    tok=create_token({'sub':str(u.id)})
    return Token(access_token=tok)
