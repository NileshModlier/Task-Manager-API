from prometheus_client import Counter, Histogram, generate_latest, CONTENT_TYPE_LATEST
from starlette.responses import Response

REQUEST_COUNT = Counter('task_api_requests_total','Total Requests',['method','path','status'])
LATENCY = Histogram('task_api_request_latency_ms','Req Latency',['method','path','status'])

async def metrics_endpoint():
    return Response(generate_latest(), media_type=CONTENT_TYPE_LATEST)
