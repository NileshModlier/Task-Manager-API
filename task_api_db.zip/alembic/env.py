
from alembic import context
from sqlalchemy import pool
from sqlalchemy.engine import create_engine
from app.database import Base, DATABASE_URL

def run_migrations_offline():
    url = DATABASE_URL.replace('aiosqlite','pysqlite')
    context.configure(url=url, target_metadata=Base.metadata, literal_binds=True)
    with context.begin_transaction():
        context.run_migrations()

def run_migrations_online():
    connectable = create_engine(DATABASE_URL.replace('aiosqlite','pysqlite'), poolclass=pool.NullPool)
    with connectable.connect() as connection:
        context.configure(connection=connection, target_metadata=Base.metadata)
        with context.begin_transaction():
            context.run_migrations()

if context.is_offline_mode():
    run_migrations_offline()
else:
    run_migrations_online()
