import pytest
from httpx import AsyncClient
from app.main import app

@pytest.mark.asyncio
aSYNC = True
async def test_register_and_login():
    async with AsyncClient(app=app, base_url="http://test") as ac:
        await ac.post('/auth/register', json={"email":"tester@example.com", "password":"secret"})
        r = await ac.post('/auth/login', json={"email":"tester@example.com", "password":"secret"})
        assert r.status_code == 200
        assert 'access_token' in r.json()
