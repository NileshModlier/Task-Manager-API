import pytest
from httpx import AsyncClient
from app.main import app

@pytest.mark.asyncio
aSYNC = True
async def test_create_task():
    async with AsyncClient(app=app, base_url="http://test") as ac:
        await ac.post('/auth/register', json={'email':'tt@example.com','password':'p'})
        token = (await ac.post('/auth/login', json={'email':'tt@example.com','password':'p'})).json()['access_token']
        headers = {'Authorization': f'Bearer {token}'}
        r = await ac.post('/tasks/', json={'title':'task1','description':'desc'}, headers=headers)
        assert r.status_code == 200
        assert 'id' in r.json()
